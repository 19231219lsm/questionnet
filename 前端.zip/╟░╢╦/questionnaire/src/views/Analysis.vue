<template>
  <div class="grey">
    <div class="analysis">
      <div class="title">{{ this.titleContent }}</div>
      <!-- this.$route.query.id -->
      <div class="total">共计{{ this.totalNum }}条数据</div>
      <div class="line"></div>

      <div class="statistic" v-for="ques in data.statistic" :key="ques.index">
        <Checkboxana
          v-if="ques.type == 2"
          :quesnumber="ques.qusenumber"
          :isRequired="ques.isrequired"
          :chooseNumber="ques.chooseNumber"
          :chooseRatio="ques.chooseRadio"
          :title="ques.title"
        ></Checkboxana>
        <Judgeana
          v-if="ques.type == 5"
          :quesnumber="ques.quesnumber"
          :isRequired="ques.isRequired"
          :chooseNumber="ques.chooseNumber"
          :chooseRatio="ques.chooseRadio"
          :title="ques.title"
        ></Judgeana>
        <Evaluationana
          v-if="ques.type == 4"
          :quesnumber="ques.quesnumber"
          :isRequired="ques.isRequired"
          :chooseNumber="ques.chooseNumber"
          :chooseRatio="ques.chooseRadio"
          :title="ques.title"
        ></Evaluationana>
        <Radioana
          v-if="ques.type == 1"
          :quesnumber="ques.quesnumber"
          :isRequired="ques.isRequired"
          :chooseNumber="ques.chooseNumber"
          :chooseRatio="ques.chooseRadio"
          :title="ques.title"
        ></Radioana>
      </div>
      <!-- <div class="statistics">
        <Checkboxana
          v-if="statistic[0].type == 2"
          :quesnumber="statistic[0].quesnumber"
          :isRequired="statistic[0].isRequired"
          :chooseNumber="statistic[0].chooseNumber"
          :chooseRatio="statistic[0].chooseRadio"
          :title="statistic[0].title"
        ></Checkboxana>
        <Judgeana
          v-if="statistic[1].type == 5"
          :quesnumber="statistic[1].quesnumber"
          :isRequired="statistic[1].isRequired"
          :chooseNumber="statistic[1].chooseNumber"
          :chooseRatio="statistic[1].chooseRadio"
          :title="statistic[1].title"
        ></Judgeana>
        <Evaluationana
          v-if="statistic[2].type == 4"
          :quesnumber="statistic[2].quesnumber"
          :isRequired="statistic[2].isRequired"
          :chooseNumber="statistic[2].chooseNumber"
          :chooseRatio="statistic[2].chooseRadio"
          :title="statistic[2].title"
          :scores="statistic[2].scores"
        ></Evaluationana>
        <Radioana
          v-if="statistic[3].type == 1"
          :quesnumber="statistic[3].quesnumber"
          :isRequired="statistic[3].isRequired"
          :chooseNumber="statistic[3].chooseNumber"
          :chooseRatio="statistic[3].chooseRadio"
          :title="statistic[3].title"
        ></Radioana>
      </div> -->
    </div>
  </div>
</template>

<style scoped src="../css/Analysis.css">
</style>

<script>
import Checkboxana from "../components/Checkboxana.vue";
import { request } from "../network/request";
import Judgeana from "../components/Judgeana.vue";
import Evaluationana from "../components/Evaluationana.vue";
import Radioana from "../components/Radioana.vue";

export default {
  components: {
    Checkboxana,
    Judgeana,
    Evaluationana,
    Radioana,
  },
  data() {
    return {
      // id: this.$router.query.id,
      titleContent: "",
      totalNum: "",
      statistic: [],
    };
  },
  created() {
    // var obj1 = {
    //   type: 2,
    //   quesnumber: 10,
    //   isRequired: true,
    //   chooseNumber: ["3", "6", "9", "12"],
    //   chooseRadio: ["10%", "20%", "30%", "40%"],
    //   title: "asdf",
    // };
    // var obj2 = {
    //   type: 5,
    //   quesnumber: 8,
    //   isRequired: false,
    //   chooseNumber: ["6", "6"],
    //   chooseRadio: ["50%", "50%"],
    //   title: "判断",
    // };
    // var obj3 = {
    //   type: 4,
    //   quesnumber: 5,
    //   isRequired: true,
    //   scores: ["1", "3", "5", "7"],
    //   chooseNumber: ["6", "6", "18", "30"],
    //   chooseRadio: ["10%", "10%", "30%", "50"],
    //   title: "评分",
    // };
    // var obj4 = {
    //   type: 1,
    //   quesnumber: 2,
    //   isRequired: true,
    //   chooseNumber: ["1", "2", "3", "4"],
    //   chooseRadio: ["10%", "20%", "30%", "40%"],
    //   title: "单选",
    // };
    // this.statistic.push(obj1);
    // this.statistic.push(obj2);
    // this.statistic.push(obj3);
    // this.statistic.push(obj4);

    request({
      url: "/analysis",
      method: "get",
      params: {
        id: this.id,
      },
    }).then((res) => {
      console.log(res),
        (this.titleContent = res.data.titleContent),
        (this.statistic = res.data.statistic),
        (this.totalNum = res.data.totalNum);
    });
  },
};
</script>
