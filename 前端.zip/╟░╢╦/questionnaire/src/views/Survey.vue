<template>
    <div id="Survey">
        <div id="mainPart">
            <div id="surveyTitle">
                {{data.titleContent}}
            </div>
            <div id="surveyIntro">
                {{data.info}}
            </div>
            <div 
            class="surveyContent" 
            v-for="ques in data.survey"
            :key ="ques.index"
            >
                <Radio 
                v-if="ques.type==1"
                :needOrder="data.needOrder"
                :number="ques.number"
                :status="0"
                :theTitle="ques.title"
                :theDescription="ques.description"
                :theChoices="ques.choices"
                :theMust="ques.must"
                :readOnly="this.readOnly"
                @getResult="change"
                >
                </Radio>

                <Checkbox 
                v-if="ques.type==2"
                :needOrder="data.needOrder"
                :number="ques.number"
                :status="0"
                :theTitle="ques.title"
                :theDescription="ques.description"
                :theChoices="ques.choices"
                :theMust="ques.must"
                :readOnly="this.readOnly"
                @getResult="change"
                >
                </Checkbox>

                <Text 
                v-if="ques.type==3"
                :needOrder="data.needOrder"
                :number="ques.number"
                :status="0"
                :theTitle="ques.title"
                :theDescription="ques.description"
                :theMust="ques.must"
                :readOnly="this.readOnly"
                @getResult="change"
                >
                </Text>

                <Evaluation
                v-if="ques.type==4"
                :needOrder="data.needOrder"
                :number="ques.number"
                :status="0"
                :theTitle="ques.title"
                :theDescription="ques.description"
                :theMust="ques.must"
                :theChoices="ques.choices"
                :readOnly="this.readOnly"
                @getResult="change"
                >
                </Evaluation>

                <Judge
                v-if="ques.type==5"
                :needOrder="data.needOrder"
                :number="ques.number"
                :status="0"
                :theTitle="ques.title"
                :theDescription="ques.description"
                :theMust="ques.must"
                :readOnly="this.readOnly"
                @getResult="change"
                >
                </Judge>
            </div>
            <div id="btn">
                <el-button @click="upload">提交问卷</el-button>
            </div>
        </div>
    </div>
</template>

<style src="../css/Survey.css" scoped></style>

<script>
import Radio from "../components/Radio.vue"
import Checkbox from "../components/Checkbox.vue"
import Text from "../components/Text.vue"
import Evaluation from "../components/Evaluation.vue"
import Judge from "../components/Judge.vue"
import {request} from '../network/request';

export default {
    components: {
        Radio,Checkbox, Text, Evaluation, Judge
    },
    data(){
        return {
            data: {
                // titleContent: "我的第一份问卷",
                titleContent: '',
                // info: "希望你喜欢",
                info: '',
                needOrder: true,
                survey: [],
                readOnly: false,
            }
        }
    },
    // mounted(){
    //     window.onbeforeunload = e => {
    //         return '';
    //     };
    // },
    methods: {
        change(i, num){
            console.log(this.data)
            console.log(this.data.survey)
            this.data.survey[num-1].answer = i;
        },
        upload(){
            for(var i in this.data.survey){
                if(this.data.survey[i].answer.length == 0 && this.data.survey[i].must==1){
                    this.$message({
                        message: "请至少填写问卷所有必答题",
                        type: "warning"
                        });
                    return;
                }
            }
            console.log(this.data)
            request({
                url: '/survey',
                method: 'post',
                data: {
                    id: this.$route.query.id,
                    data: this.data
                }
            }).then(res => {
                console.log(res) 
                if(res.data.res == 1){
                    this.$message({
                    message: "已提交问卷",
                    type: "success"
                    });
                    this.$router.push({path: '/toend'});
                }
                else{
                    this.$message({
                    message: "提交问卷失败",
                    type: "warning"
                    });
                }
            })
                
        }
    },
    created(){
        var obj1 = {
            type: 1,
            number: 1,
            title: "第一个问题",
            description: "此时无声胜有声",
            must: true,
            choices: ["Apple", "Samsung", "Huawei"],
            answer: ''
        }
        var obj2 = {
            type: 2,
            number: 2,
            title: "第二个问题",
            description: "银瓶乍破水浆迸",
            must: false,
            choices: ["Xiaomi", "Vivo", "Oppo", "Meizu"],
            answer: ''
        }
        var obj3 = {
            type: 3,
            number: 3,
            title: "第三个问题",
            description: "春江潮水连海平",
            must: true,
            choices: ["Xiaomi", "Vivo", "Oppo", "Meizu"],
            answer: ''
        }
        var obj4 = {
            type: 4,
            number: 4,
            title: "第四个问题",
            description: "海上明月共潮生",
            must: false,
            choices: [10],
            answer: ''
        }
        var obj5 = {
            type: 5,
            number: 5,
            title: "第五个问题",
            description: "人面不知何处去",
            must: true,
            choices: ["Xiaomi", "Vivo", "Oppo", "Meizu"],
            answer: ''
        }
        //this.data.survey.push(obj1)
        //this.data.survey.push(obj2)
        //this.data.survey.push(obj3)
        //this.data.survey.push(obj4)
        //this.data.survey.push(obj5)

        request({
             url:"/survey",
             method: "get",
             params: {
                 id: this.$route.query.id,
             }
         }).then(res => {
             console.log(res);
            if(res.data.status != 1){
               //this.$router.push({path: '/toerror'});
           }
            this.data = res.data;
         })
    }
}
</script>