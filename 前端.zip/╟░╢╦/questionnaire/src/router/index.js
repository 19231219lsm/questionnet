import { createRouter, createWebHistory } from "vue-router";

const routes = [
  {
    path: "/",
    name: "Home",
    component: () => import("../views/Home.vue"),
  },
  {
    path: "/about",
    name: "About",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () =>
      import(/* webpackChunkName: "about" */ "../views/About.vue"),
  },
  {
    path: "/tomanage",
    name: "Manage",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import("../views/Manage.vue"),
  },
  {
    path: "/tologin",
    name: "Login",
    component: () => import("../views/Login.vue"),
  },
  {
    path: "/toregister",
    name: "Register",
    component: () => import("../views/Register.vue"),
  },
  {
    path: "/torecycle",
    name: "Recycle",
    component: () => import("../views/Recycle.vue"),
  },
  {
    path: "/toedit",
    name: "Edit",
    component: () => import("../views/Edit.vue")
  },
  {
    path: "/tosurvey",
    name: "Survey",
    component: () => import("../views/Survey.vue")
  },
  {
    path: "/toanalysis",
    name: "Analysis",
    component: () => import("../views/Analysis.vue")
  },
  {
    path: "/topreview",
    name: "Preview",
    component: () => import("../views/Preview.vue")
  },
  {
    path: "/toepidemic",
    name: "Epidemic",
    component: () => import("../views/Epidemic.vue")
  },
];

const router = createRouter({
  mode: 'history',
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

export default router;
